# Vue 3 + Tiptap ⚡

> 基于 Vue3 +Ant-Design-Vue+Tiptap 二次开发一个富文本编辑器

<p>
  <a href="https://htmlxudong.github.io/index.html" target="_blank" rel="noopener noreferrer">
    <img width="100%" src="./public/editor.png" alt="vue3-editor"/>
  </a>
</p>

[在线预览 github](https://htmlxudong.github.io/index.html)

## 克隆代码到本地

```shell

# github
git clone https://github.com/htmlxudong/vue3-tiptap.git

# gitee
git clone https://gitee.com/xd_web/vue3-tiptap.git

```

## 安装依赖 📦

```
pnpm install or npm install

```

## 运行项目 🚀

```
npm run dev

```



## 技术栈 🥇

核心：vue3 + ant-design-vue + vite

代码提交：husky、commitlint

代码格式化：preitter

## 感谢 🌸

该项目主要借鉴于以下这些项目。

- [tiptap](https://github.com/ueberdosis/tiptap)
- [element-tiptap](https://github.com/Leecason/element-tiptap)
- [tiptap 文档](https://tiptap.dev/docs/editor/introduction)

## 更新日志 📄

- 2024.03.15
